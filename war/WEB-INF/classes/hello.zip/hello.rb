require 'sinatra'
get'/' do 
	"Hello from Cloud Foundry"
end
